import java.io.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Teacher {
	//����Ϊ��Ա����
	private String m_name=new String();
	private String m_direction=new String();
	private String m_email=new String();
	private String m_phoneNumber=new String();
	private String m_information=new String();
	
	//����Ϊ��Ա����
	//���캯��
	public Teacher(String filePath) throws IOException{
		File htmlFile=new File(filePath);
		analyseHTML(htmlFile);
	}
	//����html
	public void analyseHTML(File htmlFile) throws IOException{
		Document document=Jsoup.parse(htmlFile,"utf-8");
		Elements nameElement=document.select("h1");
		m_name=nameElement.text();
		Elements informationElement=document.select("p");
		analyseInformation(informationElement.text());
		analyseEmail(informationElement.text());
		analysePhoneNumber(informationElement.text());
	}
	//��ȡ�绰����
	public String getPhoneNumber(){
		return m_phoneNumber;
	}
	//��ȡ�о�����
	public String getDirection(){
		return m_direction;
	}
	
	//��ȡe-mail
	public String getEmail(){
		return m_email;
	}
	//��ȡ������Ϣ
	public String getInformation(){
		return m_information;
	}
	
	//��ȡ����
	public String getName(){
		return m_name;
	}
	
	//����ļ�
	public void outToFile() throws IOException{
		FileWriter out=new FileWriter("result.txt");
		out.write("������\r\n"+m_name+"\r\n");
		out.write("�о�����\r\n"+m_direction+"\r\n");
		out.write("e-mail��\r\n"+m_email+"\r\n");
		out.write("�绰���룺\r\n"+m_phoneNumber+"\r\n");
		out.write("���˼�飺\r\n"+m_information+"\r\n");
		out.close();
	}
	
	//����Ϊ���ߺ���
	//�����绰����
	private void analysePhoneNumber(String information){
		Pattern pattern =Pattern.compile("[0-9]{3}-[0-9]{8}");
		Matcher matcher=pattern.matcher(information);
		if(matcher.find()){
			m_phoneNumber=matcher.group();
		}
	}
	
	//����Email
	private void analyseEmail(String information){
		Pattern pattern=Pattern.compile("[a-z0-9A-Z]+@[a-z0-9A-Z]([a-z0-9A-Z]*\\.)+[a-zA-Z]{2,3}");
		Matcher matcher=pattern.matcher(information);
		if(matcher.find()){
		m_email=matcher.group();
		}
	}
	
	//����������Ϣ
	private void analyseInformation(String information){
		Scanner scanner=new Scanner(information);
		for(int i=0;i<8;i++){
			if(i==4){
				m_direction=scanner.next();
			}
			scanner.next();
		}
		while(scanner.hasNext()){
			m_information+=scanner.next();
			m_information+=" ";
		}
	}
}
