import java.io.File;
import java.io.IOException;


public class Main2014302580205 {
	public static void main(String[] argc) throws IOException{
		String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing";
		HttpRequest response=HttpRequest .get(url);
		String fileName="test.html";
		response.receive(new File(fileName));
		Teacher teacher=new Teacher(fileName);
		teacher.outToFile();
	}
}
